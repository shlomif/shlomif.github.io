package MikMod;

public class ENVPT extends Object
{
	public short pos;
	public short val;
}
