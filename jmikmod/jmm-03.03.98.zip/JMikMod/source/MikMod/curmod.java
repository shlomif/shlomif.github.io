package MikMod;

public class curmod extends Object
{
	public String version;
	public String driver;
	public String filename;
	public String file_output;
	public String name_type;
	public String status;
	public short patpos;
	public short sngpos;
	public short numpat;
	public short numpos;
	public boolean deleted;
	public short       flags;
	public String songname;		/* name of the song */
	public String modtype;		/* string type of module */
	public String comment;		/* module comments */
}