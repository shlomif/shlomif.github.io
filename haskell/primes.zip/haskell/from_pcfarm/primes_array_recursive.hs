
import Array

primes_map :: Int -> Array Int Bool
primes_map how_much = ret where
    ret = accumArray (\x -> \y -> (and [x,y])) True (2,how_much) 
        ([(i*j,False) | i <- [2 .. mybound], j <- [i .. (how_much `div` i)] ])
        
    mybound :: Int
    mybound = ceiling(sqrt(fromIntegral(how_much)))

primes :: Int -> [Int]
primes how_much = filter (mymap!) (indices mymap) where
    mymap = (primes_map how_much)

