
import Array

accum_append [] = []
accum_append (a:as) = a ++ accum_append(as)

myfunc :: IO () -> Bool
myfunc a = True

fibs :: Int -> Array Int Int
fibs n = a  where 
    a = accumArray (\x -> \y -> y) 0 (0,n) ([(0, 1), (1, 1)] ++ 
                     [(i, a!(i-2) + a!(i-1)) | i <- [2..n]] ++
                     [(i, ((a!(i-1))*2)) | i <- reverse([1 .. n])])

fibs_r :: Int -> Array Int Int
fibs_r n = a  where 
    a = accumArray (\x -> \y -> y) 0 (0,n) ([(n, 1), (n-1, 1)] ++ 
                     [(i, a!(i+1) + a!(i+2)) | i <- reverse([0..(n-2)])] ++
                     [(i, (a!(i+1))*2) | i <- reverse([0 .. n-1 ])]
                     ) 


primes_map :: Int -> Array Int Bool
primes_map how_much = ret where
    --ret = accumArray (\x -> \y -> y) True (2,how_much) ([(i*2,False) | i <- [2 .. (how_much `div` 2)]] ++ (accum_append (map (\p -> (if ret!i then ([ (p*i,False) | i <- [p .. (how_much `div` p)]]) else [])) [ 3 .. mybound])))
    --ret = accumArray (\x -> \y -> y) True (2,how_much) ([(i*j,False) | i <- [2 .. mybound], j <- (if (ret!i) then [i .. (how_much `div` i)] else [])])
    flag :: Bool
    flag = False 
    ret = accumArray (\x -> \y -> (and [x,y])) True (2,how_much) 
        (
            [(i*2,False) | i <- [2 .. how_much `div` 2]] ++
            [(i*3,False) | i <- [3 .. how_much `div` 3]] ++
            [(i*j,False) | i <- [2 .. mybound], ret!i, j <- [i .. (how_much `div` i)] ]
            )
        
    --ret = array (2,how_much) ([(i,True) | i <- [2 .. how_much]] ++ [(i*2,False) | i <- [2 .. (how_much `div` 2)]])
    --([(i,True) | i <- [2 .. how_much]] ++ [(i*2,False) | i <- [2 .. (how_much `div` 2)]])
    --ret = accumArray (\x -> \y -> y) True (1,2) [(2,True),(1,False),(1,True)]
    mybound :: Int
    mybound = ceiling(sqrt(fromIntegral(how_much)))

primes :: Int -> [Int]
primes how_much = filter (mymap!) (indices mymap) where
    mymap = (primes_map how_much)

