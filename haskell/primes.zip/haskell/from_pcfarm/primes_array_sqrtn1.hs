
import Array

primes_map :: Int -> Array Int Bool
primes_map how_much = ret where
    ret = accumArray (\x -> \y -> y) True (2,how_much) convert_list
        
    convert_list :: [ (Int, Bool) ]
    convert_list = ([(p*j,False) | p <- (primes mybound), j <- [p .. (how_much `div` p)] ])
        
    mybound :: Int
    mybound = ceiling(sqrt(fromIntegral(how_much)))

test how_much = 
    print (length ([(p*j,False) | p <- (primes mybound), j <- [p .. (how_much `div` p)] ])) where
        
    mybound :: Int
    mybound = ceiling(sqrt(fromIntegral(how_much)))


primes :: Int -> [Int]
primes 2 = [2]
primes how_much = filter (mymap!) (indices mymap) where
    mymap = (primes_map how_much)

