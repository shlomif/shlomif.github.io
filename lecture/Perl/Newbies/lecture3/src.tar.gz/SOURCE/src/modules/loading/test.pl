#!/usr/bin/env perl

use strict;
use warnings;

use MyModule;

# Notice that we use "::" to call the function out of the module.
MyModule::a_function();
