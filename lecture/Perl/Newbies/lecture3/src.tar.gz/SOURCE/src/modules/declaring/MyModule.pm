# This is the file MyModule.pm
#

package MyModule;

use strict;
use warnings;

sub a_function
{
    print "Hello, World!\n";
}

1;
