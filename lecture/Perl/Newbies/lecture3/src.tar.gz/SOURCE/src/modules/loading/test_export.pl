#!/usr/bin/env perl

use strict;
use warnings;

use Calc;

my $m = 200;
my $n = 15;

print "gcd($m,$n) == " , gcd($m,$n), "\n";
