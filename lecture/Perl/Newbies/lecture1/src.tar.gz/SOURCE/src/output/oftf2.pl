print "One Fish,\n"; print "Two Fish,\n";
print "Red Fish,\n"; print "Blue Fish.\n";
