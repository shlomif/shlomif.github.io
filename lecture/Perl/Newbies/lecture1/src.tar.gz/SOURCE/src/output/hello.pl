print "Hello, World!\n";
