print "Hello," . " " . "World!" . "\n" .
    "And this is the second line.\n";
