print substr("A long string", 3), "\n";
print substr("A long string", 1, 4), "\n";
print substr("A long string", 0, 6), "\n";
