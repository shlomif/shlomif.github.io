print "I said \"hi!\" to myself, and received no reply.\n";

print "This program will cost you \$100 dollars.\n";

print "The KDE\\GNOME holy war makes life in the Linux world " .
      "more interesting.\n";
