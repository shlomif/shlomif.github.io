print "The whole part of 5.67 is " . int(5.67) . "\n";
