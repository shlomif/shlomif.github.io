print "5 + 6 = ", 5+6, "\n";
print "(2 + 3) * 6 = ", (2+3)*6, "\n";
print "2 + 3 * 6 = ", 2+3*6, "\n";
print "2 raised to the power of 8 is ", 2**8, "\n";
print "10-5 = ", 10-5, ". 5-10 = ", 5-10, "\n";
print "2/3 = ", 2/3, "\n";
