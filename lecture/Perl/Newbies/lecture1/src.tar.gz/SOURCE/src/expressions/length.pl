print length("There's more than one way to do it"), "\n";
