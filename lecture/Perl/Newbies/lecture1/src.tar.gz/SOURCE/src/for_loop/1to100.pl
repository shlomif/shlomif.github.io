for $i (1..100)
{
    print $i, "\n";
}
