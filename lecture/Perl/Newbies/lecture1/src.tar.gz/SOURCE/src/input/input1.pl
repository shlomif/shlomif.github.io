print "Please enter your name:\n";
$name = <>;
chomp($name);
print "Hello, ", $name, "!\n";
