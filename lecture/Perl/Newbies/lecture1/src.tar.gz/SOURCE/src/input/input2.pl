print "Please enter a string:";
$string = <>;
chomp($string);
print "The string you entered contains ", length($string), " characters.\n";
