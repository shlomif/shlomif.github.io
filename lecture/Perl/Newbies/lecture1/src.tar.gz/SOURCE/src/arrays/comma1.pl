@lines = ("One fish", "Two fish", "Red fish", "Blue fish");

for $idx (0 .. $#lines)
{
    print $lines[$idx], "\n";
}
