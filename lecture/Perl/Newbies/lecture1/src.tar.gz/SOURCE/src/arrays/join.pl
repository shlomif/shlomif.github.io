@myarray = ("One fish", "Two fish", "Red Fish", "Blue Fish");

print join("\n", @myarray), "\n";
