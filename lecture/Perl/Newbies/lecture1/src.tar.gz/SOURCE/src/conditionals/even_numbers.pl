for $n (1 .. 100)
{
    if (($n % 3) != 0)
    {
        print $n,"\n";
    }
}
