if ($condition0)
{
}
elsif ($condition1)
{
}
elsif ($condition2)
{
}
.
.
.
else
{
}
