print "Please enter your private name:\n";
$name = <>;
chomp($name);
if (lc($name) eq "rachel")
{
    print "Your name is Rachel!\n";
}
else
{
    print "Your name is not Rachel!\n";
}
