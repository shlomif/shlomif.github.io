print "Please enter your name:\n";
$name = <>;
if (substr($name,0,1) eq "A")
{
    print "Your name starts with 'A'!\n";
}
else
{
    print "Your name does not start with 'A'!\n";
}
