#!/usr/bin/env perl

use strict;
use warnings;

print sprintf("Hello \"%s\"! Your lucky number is %i.\n", "Nathan", 65);
