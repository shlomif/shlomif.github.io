#!/usr/bin/env perl

use strict;
use warnings;

print sprintf("There is %i%% of alcohol in this beverage\n", 27);
print sprintf("%s%s\n", "This string", " ends here.");
print sprintf("650 in hex is 0x%x\n", 650);
print sprintf("650 in binary is 0b%b\n", 650);
print sprintf("3.2 + 1.6 == %f\n", 3.2+1.6);
