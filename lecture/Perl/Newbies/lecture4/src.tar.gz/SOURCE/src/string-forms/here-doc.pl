#!/usr/bin/env perl

use strict;
use warnings;


my $x = "Hello";
my $str = "There you go.";
my $true = "False";

print <<"END";
The value of \$x is: "$x"
The value of \$str is: "$str"
The value of true is: "$true"

Hoola

END
